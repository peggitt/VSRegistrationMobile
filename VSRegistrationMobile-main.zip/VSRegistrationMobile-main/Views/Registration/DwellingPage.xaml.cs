﻿namespace HSNP.Mobile.Views;

public partial class DwellingPage : ContentPage
{
	public DwellingPage()
	{
		InitializeComponent();
	}
}
