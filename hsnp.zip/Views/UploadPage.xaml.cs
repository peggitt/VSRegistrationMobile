﻿namespace HSNP.Mobile.Views;

public partial class UploadPage : ContentPage
{
	public UploadPage()
	{
		InitializeComponent();
	}
}
