﻿namespace HSNP.Mobile.Views;

public partial class UpdatesPage : ContentPage
{
	public UpdatesPage()
	{
		InitializeComponent();
	}
}
