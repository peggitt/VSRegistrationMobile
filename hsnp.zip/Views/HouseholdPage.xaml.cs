﻿namespace HSNP.Mobile.Views;
[XamlCompilation(XamlCompilationOptions.Compile)]
public partial class HouseholdPage : TabbedPage
{
	public HouseholdPage()
	{
		InitializeComponent();
	}
}
