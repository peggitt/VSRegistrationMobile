﻿namespace HSNP.Mobile.ViewModels;

public partial class HomeViewModel : BaseViewModel
{
}
